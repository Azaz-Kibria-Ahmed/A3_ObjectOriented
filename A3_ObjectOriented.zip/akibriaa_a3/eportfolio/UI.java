package eportfolio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class UI extends JFrame {
    // top panel
    private JToolBar toolbar;
    private JComboBox<String> options;

    private JLabel actionTitle;
    private JPanel mainPanel;
    private JPanel buySellPanel;
    private JPanel btnPanel;
    private JButton resetBtn;
    private JButton buyBtn;
    private JButton sellBtn;
    private JButton nextBtn;
    private JButton prevBtn;
    private JButton saveBtn;
    private JButton searchBtn;
    private JPanel welcomePanel;
    private JLabel welcomeLabel;
    private JPanel buyPanel;
    private JPanel sellPanel;
    private JLabel typeLabel;
    private JComboBox<String> typeSelect;
    private JLabel symbolLabel;
    private JTextField symbolField;
    private JLabel nameLabel;
    private JTextField nameField;
    private JLabel qtyLabel;
    private JTextField qtyField;
    private JLabel priceLabel;
    private JTextField priceField;

    private JTextField sellSymbolField;
    private JTextField sellPriceField;
    private JTextField sellQtyField;

    private JPanel messagePanel;
    private JLabel messageLabel;
    private JTextArea messageArea;
    private JScrollPane scrollPanel;

    private JPanel updatePanel;
    private JTextField updateSymbolField;
    private JTextField updateNameField;
    private JTextField updatePriceField;

    private JPanel totalGainPanel;
    private JTextField totalGainField;

    private JPanel searchPanel;
    private JTextField searchSybmolField;
    private JTextField searchNameField;
    private JTextField searchLowPriceField;
    private JTextField searchHighPriceField;

    private Portfolio portfolio;

    public UI(Portfolio myPortfolio) {
        super("ePortFolio");
        this.portfolio = myPortfolio;
        this.setSize(1000, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());

        toolbar = new JToolBar();
        String[] optArr = { "Commands", "Buy", "Sell", "Update", "Get Gain", "Search", "Quit" };
        options = new JComboBox<String>(optArr);
        options.addItemListener(new toolBarHandler());
        toolbar.add(options);
        toolbar.add(Box.createHorizontalGlue());
        this.add(toolbar, BorderLayout.NORTH);

        mainPanel = new JPanel();
        GridBagLayout mainGBL = new GridBagLayout();
        mainPanel.setLayout(mainGBL);
        GridBagConstraints c = new GridBagConstraints();
        c.ipadx = 100;

        welcomePanel = new JPanel(new GridBagLayout());
        welcomeLabel = new JLabel("<html>Welcome to ePortfolio<br/>Do all your investments here!</html>");
        welcomePanel.add(welcomeLabel, c);
        mainPanel.add(welcomePanel, c);

        // buy
        buySellPanel = new JPanel();
        buySellPanel.setLayout(new BoxLayout(buySellPanel, BoxLayout.Y_AXIS));
        actionTitle = new JLabel("Buy Investment");
        buySellPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        buySellPanel.add(actionTitle);
        Dimension dim = new Dimension(175, 25);
        buyPanel = new JPanel();
        buyPanel.setLayout(new GridBagLayout());
        c.gridy = 0;
        c.gridx = 0;
        typeLabel = new JLabel("Type");
        buyPanel.add(typeLabel, c);
        c.gridx = 1;
        String[] arr = { "Stock", "MutualFund" };
        typeSelect = new JComboBox<String>(arr);
        buyPanel.add(typeSelect, c);
        c.gridy = 1;
        c.gridx = 0;
        symbolLabel = new JLabel("Symbol");
        buyPanel.add(symbolLabel, c);
        c.gridx = 1;
        symbolField = new JTextField();
        symbolField.setPreferredSize(dim);
        buyPanel.add(symbolField, c);
        c.gridy = 2;
        c.gridx = 0;
        nameLabel = new JLabel("Name");
        buyPanel.add(nameLabel, c);
        c.gridx = 1;
        nameField = new JTextField();
        nameField.setPreferredSize(dim);
        buyPanel.add(nameField, c);
        c.gridy = 3;
        c.gridx = 0;
        qtyLabel = new JLabel("Quantity");
        buyPanel.add(qtyLabel, c);
        c.gridx = 1;
        qtyField = new JTextField();
        qtyField.setPreferredSize(dim);
        buyPanel.add(qtyField, c);
        c.gridy = 4;
        c.gridx = 0;
        priceLabel = new JLabel("Price");
        buyPanel.add(priceLabel, c);
        c.gridx = 1;
        priceField = new JTextField();
        priceField.setPreferredSize(dim);
        buyPanel.add(priceField, c);
        buyPanel.setVisible(false);

        c.gridy = 0;
        c.gridx = 0;
        buySellPanel.add(buyPanel);

        // sell
        sellPanel = new JPanel(new GridBagLayout());
        c.gridy = 0;
        c.gridx = 0;
        sellPanel.add(new JLabel("Symbol"), c);
        c.gridx = 1;
        sellSymbolField = new JTextField();
        sellSymbolField.setPreferredSize(dim);
        sellPanel.add(sellSymbolField, c);
        c.gridy = 1;
        c.gridx = 0;
        sellPanel.add(new JLabel("Quantity"), c);
        sellQtyField = new JTextField();
        sellQtyField.setPreferredSize(dim);
        c.gridx = 1;
        sellPanel.add(sellQtyField, c);
        c.gridy = 2;
        c.gridx = 0;
        sellPanel.add(new JLabel("Price"), c);
        c.gridx = 1;
        sellPriceField = new JTextField();
        sellPriceField.setPreferredSize(dim);
        sellPanel.add(sellPriceField, c);
        sellPanel.setVisible(false);

        buySellPanel.add(sellPanel);

        // update
        updatePanel = new JPanel(new GridBagLayout());
        c.gridy = 0;
        c.gridx = 0;
        updatePanel.add(new JLabel("Symbol"), c);
        c.gridx = 1;
        updateSymbolField = new JTextField();
        updateSymbolField.setEditable(false);
        updateSymbolField.setPreferredSize(dim);
        updatePanel.add(updateSymbolField, c);
        c.gridy = 1;
        c.gridx = 0;
        updatePanel.add(new JLabel("Name"), c);
        updateNameField = new JTextField();
        updateNameField.setEditable(false);
        updateNameField.setPreferredSize(dim);
        c.gridx = 1;
        updatePanel.add(updateNameField, c);
        c.gridy = 2;
        c.gridx = 0;
        updatePanel.add(new JLabel("Price"), c);
        c.gridx = 1;
        updatePriceField = new JTextField();
        updatePriceField.setPreferredSize(dim);
        updatePanel.add(updatePriceField, c);
        updatePanel.setVisible(false);

        buySellPanel.add(updatePanel);

        // get gain panel
        totalGainPanel = new JPanel(new GridBagLayout());
        c.gridy = 0;
        c.gridx = 0;
        totalGainPanel.add(new JLabel("Total Gain"), c);
        c.gridx = 1;
        totalGainField = new JTextField();
        totalGainField.setEditable(false);
        totalGainField.setPreferredSize(dim);
        totalGainPanel.add(totalGainField, c);
        totalGainPanel.setVisible(false);
        buySellPanel.add(totalGainPanel);

        // search
        searchPanel = new JPanel(new GridBagLayout());
        c.gridy = 0;
        c.gridx = 0;
        searchPanel.add(new JLabel("Symbol"), c);
        c.gridx = 1;
        searchSybmolField = new JTextField();
        searchSybmolField.setPreferredSize(dim);
        searchPanel.add(searchSybmolField, c);
        c.gridy = 1;
        c.gridx = 0;
        searchPanel.add(new JLabel("Name Keywords"), c);
        searchNameField = new JTextField();
        searchNameField.setPreferredSize(dim);
        c.gridx = 1;
        searchPanel.add(searchNameField, c);
        c.gridy = 2;
        c.gridx = 0;
        searchPanel.add(new JLabel("Low Price"), c);
        c.gridx = 1;
        searchLowPriceField = new JTextField();
        searchLowPriceField.setPreferredSize(dim);
        searchPanel.add(searchLowPriceField, c);
        c.gridy = 3;
        c.gridx = 0;
        searchPanel.add(new JLabel("High Price"), c);
        c.gridx = 1;
        searchHighPriceField = new JTextField();
        searchHighPriceField.setPreferredSize(dim);
        searchPanel.add(searchHighPriceField, c);
        searchPanel.setVisible(false);
        buySellPanel.add(searchPanel);

        c.gridy = 0;
        c.gridx = 0;
        mainPanel.add(buySellPanel, c);

        // btn panel
        BtnHandler handler = new BtnHandler();
        btnPanel = new JPanel();
        btnPanel.setLayout(new BoxLayout(btnPanel, BoxLayout.Y_AXIS));
        resetBtn = new JButton("Reset");
        resetBtn.addActionListener(handler);
        buyBtn = new JButton("Buy");
        buyBtn.addActionListener(handler);
        sellBtn = new JButton("Sell");
        sellBtn.addActionListener(handler);
        searchBtn = new JButton("Search");
        searchBtn.addActionListener(handler);
        prevBtn = new JButton("Prev");
        prevBtn.addActionListener(handler);
        nextBtn = new JButton("Next");
        nextBtn.addActionListener(handler);
        saveBtn = new JButton("Save");
        saveBtn.addActionListener(handler);
        btnPanel.add(resetBtn);
        btnPanel.add(buyBtn);
        btnPanel.add(sellBtn);
        btnPanel.add(searchBtn);
        btnPanel.add(resetBtn);
        btnPanel.add(prevBtn);
        btnPanel.add(nextBtn);
        btnPanel.add(saveBtn);
        btnPanel.setVisible(false);
        c.gridy = 0;
        c.gridx = 1;
        mainPanel.add(btnPanel, c);

        messagePanel = new JPanel(new BorderLayout());
        messagePanel.setPreferredSize(new Dimension(600, 200));
        messageArea = new JTextArea();
        scrollPanel = new JScrollPane(messageArea);
        scrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        messageLabel = new JLabel("Message");
        messagePanel.add(messageLabel, BorderLayout.NORTH);
        messagePanel.add(scrollPanel, BorderLayout.CENTER);
        messagePanel.setVisible(false);
        c.gridx = 0;
        c.gridy = 1;
        mainPanel.add(messagePanel, c);

        this.add(mainPanel, BorderLayout.CENTER);
        this.setVisible(true);
    }

    private class toolBarHandler implements ItemListener {

        @Override
        public void itemStateChanged(ItemEvent e) {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                switch (e.getItem().toString()) {
                    case "Commands":
                        resetBtn.doClick();
                        welcomePanel.setVisible(true);
                        btnPanel.setVisible(false);
                        messagePanel.setVisible(false);
                        buyPanel.setVisible(false);
                        btnPanel.setVisible(false);
                        totalGainPanel.setVisible(false);
                        searchPanel.setVisible(false);

                        break;
                    case "Buy":
                        resetBtn.doClick();

                        actionTitle.setText("Buy Investments");
                        buyBtn.setVisible(true);
                        sellBtn.setVisible(false);
                        resetBtn.setVisible(true);
                        nextBtn.setVisible(false);
                        prevBtn.setVisible(false);
                        saveBtn.setVisible(false);
                        searchBtn.setVisible(false);

                        welcomePanel.setVisible(false);
                        btnPanel.setVisible(true);
                        mainPanel.setVisible(true);
                        buyPanel.setVisible(true);
                        btnPanel.setVisible(true);
                        messagePanel.setVisible(true);
                        messageLabel.setText("Message");
                        messageArea.setText("");
                        sellPanel.setVisible(false);
                        totalGainPanel.setVisible(false);
                        searchPanel.setVisible(false);

                        break;

                    case "Sell":
                        resetBtn.doClick();

                        actionTitle.setText("Sell Investments");
                        buyBtn.setVisible(false);
                        sellBtn.setVisible(true);
                        resetBtn.setVisible(true);
                        nextBtn.setVisible(false);
                        prevBtn.setVisible(false);
                        saveBtn.setVisible(false);
                        searchBtn.setVisible(false);

                        welcomePanel.setVisible(false);
                        btnPanel.setVisible(true);
                        messagePanel.setVisible(true);
                        messageLabel.setText("Message");
                        messageArea.setText("");
                        mainPanel.setVisible(true);
                        sellPanel.setVisible(true);
                        buyPanel.setVisible(false);
                        totalGainPanel.setVisible(false);
                        searchPanel.setVisible(false);

                        break;
                    case "Update":
                        resetBtn.doClick();

                        actionTitle.setText("Update Investments");
                        buyBtn.setVisible(false);
                        sellBtn.setVisible(false);
                        resetBtn.setVisible(false);
                        searchBtn.setVisible(false);
                        nextBtn.setVisible(true);
                        prevBtn.setVisible(true);
                        saveBtn.setVisible(true);

                        welcomePanel.setVisible(false);
                        btnPanel.setVisible(true);
                        messagePanel.setVisible(true);
                        messageLabel.setText("Message");
                        messageArea.setText("");
                        mainPanel.setVisible(true);
                        sellPanel.setVisible(false);
                        buyPanel.setVisible(false);
                        updatePanel.setVisible(true);
                        totalGainPanel.setVisible(false);
                        searchPanel.setVisible(false);

                        updateSymbolField.setText(portfolio.getInvestments().get(0).getSymbol());
                        updateNameField.setText(portfolio.getInvestments().get(0).getName());
                        updatePriceField.setText(String.valueOf(portfolio.getInvestments().get(0).getPrice()));

                        break;
                    case "Get Gain":
                        resetBtn.doClick();

                        actionTitle.setText("Investments Gains");
                        welcomePanel.setVisible(false);
                        btnPanel.setVisible(false);
                        totalGainPanel.setVisible(true);
                        buyPanel.setVisible(false);
                        sellPanel.setVisible(false);
                        messagePanel.setVisible(true);
                        updatePanel.setVisible(false);
                        messageLabel.setText("Individual Gains");
                        messageArea.setText("");
                        searchPanel.setVisible(false);
                        System.out.println("gains " + portfolio.getNetGains());
                        totalGainField.setText(String.valueOf(portfolio.getNetGains()));
                        String allGains = "";
                        for (Investment i : portfolio.getInvestments()) {
                            allGains += String.format("%s: $%.2f\n", i.getSymbol(), i.getBookValue());
                        }
                        messageArea.setText(allGains);
                        break;
                    case "Search":
                        resetBtn.doClick();
                        actionTitle.setText("Search Investments");
                        buyBtn.setVisible(false);
                        sellBtn.setVisible(false);
                        resetBtn.setVisible(true);
                        nextBtn.setVisible(false);
                        prevBtn.setVisible(false);
                        saveBtn.setVisible(false);
                        searchBtn.setVisible(true);

                        searchPanel.setVisible(true);
                        welcomePanel.setVisible(false);
                        btnPanel.setVisible(true);
                        messagePanel.setVisible(true);
                        messageLabel.setText("Search Results");
                        messageArea.setText("");
                        mainPanel.setVisible(true);
                        sellPanel.setVisible(false);
                        buyPanel.setVisible(false);
                        totalGainPanel.setVisible(false);

                        break;
                    case "Quit":
                        portfolio.updateDataFile();
                        System.exit(0);
                        break;
                }

            }
        }
    }

    private class BtnHandler implements ActionListener {
        int i = 0;

        public void actionPerformed(ActionEvent e) {

            String inType, inSymbol, inName;
            int inQty;
            double inPrice;
            String high, low;
            JButton btn = (JButton) e.getSource();

            switch (btn.getText()) {
                case "Buy":
                    try {
                        inType = typeSelect.getSelectedItem().toString();
                        inSymbol = symbolField.getText();
                        inName = nameField.getText();
                        inQty = Integer.parseInt(qtyField.getText());
                        inPrice = Double.parseDouble(priceField.getText());

                        if (portfolio.investmentBought(inSymbol)) {
                            portfolio.updateBoughtInvestment(inSymbol, inPrice, inQty);
                        } else {
                            portfolio.addNewInvestment(inType, inSymbol, inName, inPrice, inQty);
                        }
                        resetBtn.doClick();
                        messageArea.setText(String.format("%d shares of %s bought @ %f", inQty, inSymbol, inPrice));
                    } catch (NumberFormatException ex) {
                        messageArea.setText("Invalid Price or Qty");
                    } catch (Exception ex) {
                        messageArea.setText(ex.getMessage());
                    }
                    break;

                case "Sell":
                    try {
                        inSymbol = sellSymbolField.getText();
                        inPrice = Double.parseDouble(sellPriceField.getText());
                        inQty = Integer.parseInt(sellQtyField.getText());
                        portfolio.sellInvestment(inSymbol, inPrice, inQty);
                        resetBtn.doClick();
                        messageArea.setText(String.format("Sold %d shares of %s @ %f", inQty, inSymbol, inPrice));
                    } catch (NumberFormatException ex) {
                        messageArea.setText("Invalid Price or Qty");
                    } catch (Exception ex) {
                        messageArea.setText(ex.getMessage());
                    }
                    break;

                case "Update":

                    break;

                case "Prev":

                    i--;
                    if (i < 0)
                        i = 0;
                    updateSymbolField.setText(portfolio.getInvestments().get(i).getSymbol());
                    updateNameField.setText(portfolio.getInvestments().get(i).getName());
                    updatePriceField.setText(String.valueOf(portfolio.getInvestments().get(i).getPrice()));

                    break;

                case "Next":
                    i++;
                    System.out.println(i);
                    if (i == portfolio.getInvestments().size())
                        i = portfolio.getInvestments().size() - 1;

                    updateSymbolField.setText(portfolio.getInvestments().get(i).getSymbol());
                    updateNameField.setText(portfolio.getInvestments().get(i).getName());
                    updatePriceField.setText(String.valueOf(portfolio.getInvestments().get(i).getPrice()));

                    break;

                case "Save":
                    try {
                        inPrice = Double.parseDouble(updatePriceField.getText());
                        inSymbol = updateSymbolField.getText();
                        double oldPrice = portfolio.getInvestments().get(i).getPrice();
                        portfolio.getInvestments().get(i).setPrice(inPrice);
                        resetBtn.doClick();
                        messageArea.setText(
                                String.format("Price of %s changed from %.2f to %.2f", inSymbol, oldPrice, inPrice));
                    } catch (Exception ex) {
                        messageArea.setText("Invalid Price");
                    }
                    break;

                case "Search":

                    try {
                        inSymbol = searchSybmolField.getText();
                        inName = searchNameField.getText();
                        System.out.println(inName);
                        low = searchLowPriceField.getText();
                        high = searchHighPriceField.getText();

                        ArrayList<Investment> res = portfolio.searchAllInvestments(inSymbol, inName, low, high);
                        if (res.isEmpty()) {
                            messageArea.setText("No results");
                        } else {
                            messageArea.setText("");
                            for (Investment i : res) {
                                messageArea.append(i.toString() + "\n");
                            }
                        }
                    } catch (Exception ex) {
                        messageArea.setText("Invalid search criteria");
                    }
                    break;

                case "Reset":
                    typeSelect.setSelectedIndex(0);
                    symbolField.setText("");
                    nameField.setText("");
                    qtyField.setText("");
                    priceField.setText("");
                    sellSymbolField.setText("");
                    sellPriceField.setText("");
                    sellQtyField.setText("");
                    updatePriceField.setText("");
                    totalGainField.setText("");
                    searchSybmolField.setText("");
                    searchNameField.setText("");
                    searchLowPriceField.setText("");
                    searchHighPriceField.setText("");
                    messageArea.setText("");

            }
        }
    }
}
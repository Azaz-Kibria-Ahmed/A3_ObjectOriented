package eportfolio;

public class Investment {
	private String symbol;
	private String name;
	private double price;
	private int quantity;
	private double bookValue;
	private double commission;

	
	public Investment(String symbol, String name, double price, int quantity) {
		this.setSymbol(symbol);
		this.setName(name);
		this.setPrice(price);
		this.setQuantity(quantity);
		this.setBookValue(price*quantity);
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getBookValue() {
		return bookValue;
	}

	public void setBookValue(double bookValue) {
		this.bookValue = bookValue;
	}
	
	public boolean equals(Stock other) {
		return other.getSymbol().equals(this.symbol);
	}

	public double getCommission() {
		return commission;
	}


	public void setCommission(double commission) {
		this.commission = commission;
	}

	
	public String toString() {
		return String.format("%s, Name: %s, Price: $%f, Qty: %d, Book Value: $%f", this.symbol, this.name,this.price,this.quantity,this.bookValue);
	}
	
	
}

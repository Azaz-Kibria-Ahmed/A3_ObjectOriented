package eportfolio;

public class A1 {

	public static void main(String[] args) throws Exception {

		Portfolio myPortfolio = new Portfolio(args[0]);
		new UI(myPortfolio);
	}

}

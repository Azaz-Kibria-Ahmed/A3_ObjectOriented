package eportfolio;

public class MutualFund extends Investment
{
	
	public  MutualFund (String symbol, String name, double price, int quantity) {
		super(symbol, name, price, quantity);
	}
		
	public String toString() {
		return String.format("Mutualfund %s",super.toString());
	}
	
	
}
